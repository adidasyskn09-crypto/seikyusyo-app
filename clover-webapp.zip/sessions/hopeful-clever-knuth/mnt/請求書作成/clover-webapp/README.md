# 🍀 Clover 書類作成アプリ

請求書・領収書・見積書・点検報告書をブラウザで作成・保存・PDF出力できるウェブアプリです。

## 機能

- 📄 請求書・領収書・見積書・点検報告書の作成
- 💾 作成した書類をサーバーに保存・読込
- 📑 PDF自動生成（サーバーサイド）
- 🔌 オフライン対応（ローカル起動）

## 技術スタック

- **フロントエンド**: HTML / CSS / JavaScript（単一ファイル）
- **バックエンド**: Node.js + Express
- **データベース**: SQLite（`better-sqlite3`）
- **PDF生成**: Puppeteer

## セットアップ

### 必要なもの

- [Node.js](https://nodejs.org/) 18以上

### インストール・起動

```bash
git clone https://github.com/YOUR_USERNAME/clover-webapp.git
cd clover-webapp
npm install
npm start
```

ブラウザで http://localhost:3000 を開いてください。

### 開発モード（ファイル変更で自動再起動）

```bash
npm run dev
```

## 環境変数

`.env.example` をコピーして `.env` を作成してください。

```bash
cp .env.example .env
```

| 変数名 | デフォルト | 説明 |
|--------|-----------|------|
| `PORT` | `3000` | サーバーのポート番号 |

## API

| メソッド | パス | 説明 |
|----------|------|------|
| `GET` | `/api/documents` | 書類一覧 |
| `GET` | `/api/documents/:id` | 1件取得 |
| `POST` | `/api/documents` | 新規保存 |
| `PUT` | `/api/documents/:id` | 上書き保存 |
| `DELETE` | `/api/documents/:id` | 削除 |
| `POST` | `/api/pdf` | PDF生成 |

## デプロイ

### Railway（推奨・無料枠あり）

1. [Railway](https://railway.app) でアカウント作成
2. 「New Project」→「Deploy from GitHub repo」でこのリポジトリを選択
3. 自動でURLが発行されます

### Render

1. [Render](https://render.com) でアカウント作成
2. 「New Web Service」→ GitHubリポジトリを連携
3. Start Command: `npm start`

## ライセンス

MIT
