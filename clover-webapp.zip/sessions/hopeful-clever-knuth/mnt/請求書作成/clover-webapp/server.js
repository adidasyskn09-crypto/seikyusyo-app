const express = require('express');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: '10mb' }));
app.use(express.static(path.join(__dirname, 'public')));

// API ルート
app.use('/api/documents', require('./routes/documents'));
app.use('/api/pdf',       require('./routes/pdf'));

// それ以外はフロントエンドへ
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`✅ Clover ウェブアプリ起動: http://localhost:${PORT}`);
});
