const express = require('express');
const router = express.Router();
const db = require('../db');

// 一覧取得
router.get('/', (req, res) => {
  const { type } = req.query;
  const rows = type
    ? db.prepare('SELECT id, type, title, created_at, updated_at FROM documents WHERE type=? ORDER BY updated_at DESC').all(type)
    : db.prepare('SELECT id, type, title, created_at, updated_at FROM documents ORDER BY updated_at DESC').all();
  res.json(rows);
});

// 1件取得
router.get('/:id', (req, res) => {
  const row = db.prepare('SELECT * FROM documents WHERE id=?').get(req.params.id);
  if (!row) return res.status(404).json({ error: 'Not found' });
  row.data = JSON.parse(row.data);
  res.json(row);
});

// 保存（新規）
router.post('/', (req, res) => {
  const { type, title, data } = req.body;
  if (!type || !title || !data) return res.status(400).json({ error: 'type, title, data は必須です' });
  const result = db.prepare(
    'INSERT INTO documents (type, title, data) VALUES (?, ?, ?)'
  ).run(type, title, JSON.stringify(data));
  res.json({ id: result.lastInsertRowid });
});

// 上書き保存
router.put('/:id', (req, res) => {
  const { title, data } = req.body;
  db.prepare(
    "UPDATE documents SET title=?, data=?, updated_at=datetime('now','localtime') WHERE id=?"
  ).run(title, JSON.stringify(data), req.params.id);
  res.json({ ok: true });
});

// 削除
router.delete('/:id', (req, res) => {
  db.prepare('DELETE FROM documents WHERE id=?').run(req.params.id);
  res.json({ ok: true });
});

module.exports = router;
