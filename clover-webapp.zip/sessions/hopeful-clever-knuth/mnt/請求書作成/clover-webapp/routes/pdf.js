const express = require('express');
const router = express.Router();
const puppeteer = require('puppeteer');
const path = require('path');

// POST /api/pdf  { html: "<html>...</html>", filename: "請求書.pdf" }
router.post('/', async (req, res) => {
  const { html, filename = '書類.pdf' } = req.body;
  if (!html) return res.status(400).json({ error: 'html は必須です' });

  let browser;
  try {
    browser = await puppeteer.launch({ args: ['--no-sandbox', '--disable-setuid-sandbox'] });
    const page = await browser.newPage();
    await page.setContent(html, { waitUntil: 'networkidle0' });
    const pdfBuffer = await page.pdf({
      format: 'A4',
      printBackground: true,
      margin: { top: '10mm', bottom: '10mm', left: '10mm', right: '10mm' }
    });
    res.set({
      'Content-Type': 'application/pdf',
      'Content-Disposition': `attachment; filename*=UTF-8''${encodeURIComponent(filename)}`
    });
    res.send(pdfBuffer);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'PDF生成に失敗しました' });
  } finally {
    if (browser) await browser.close();
  }
});

module.exports = router;
