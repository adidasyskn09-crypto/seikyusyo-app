const Database = require('better-sqlite3');
const path = require('path');

const db = new Database(path.join(__dirname, 'clover.db'));

// テーブル作成
db.exec(`
  CREATE TABLE IF NOT EXISTS documents (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    type      TEXT NOT NULL,        -- 'invoice' | 'receipt' | 'estimate' | 'report'
    title     TEXT NOT NULL,
    data      TEXT NOT NULL,        -- JSON文字列
    created_at TEXT DEFAULT (datetime('now','localtime')),
    updated_at TEXT DEFAULT (datetime('now','localtime'))
  )
`);

module.exports = db;
